# SQL Project - DVD Rental

Dave Husk
QAP1
Database
SD10 - Keyin College
May 2024

This is a SQL project for the DVD Rental database. 


## Table of Contents

- [Screenshots](#screenshots)
- [Files](#files)

## Screenshots

1. Clone the repository: `git clone https://github.com/your-username/dvdrental-sql-project.git`
2. Create a new database in your preferred SQL server.
3. Import the DVD Rental database provided in the repository to create the necessary tables and populate initial data.

## Usage

1. Connect to the database using your preferred SQL client.
2. Execute the SQL queries to perform various operations on the DVD Rental database.
