from django.test import TestCase

# Create tests later on if I have time. 
